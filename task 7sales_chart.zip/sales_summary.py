import sqlite3

# Step 1: Create or connect to the database
conn = sqlite3.connect("sales_data.db")
cursor = conn.cursor()

# Step 2: Create the sales table
cursor.execute("""
CREATE TABLE IF NOT EXISTS sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product TEXT,
    quantity INTEGER,
    price REAL
)
""")

# Step 3: Insert sample data
sample_data = [
    ("Laptop", 5, 800.00),
    ("Mouse", 15, 25.00),
    ("Keyboard", 10, 45.00),
    ("Monitor", 7, 150.00),
    ("Headphones", 8, 75.00),
]

cursor.executemany("INSERT INTO sales (product, quantity, price) VALUES (?, ?, ?)", sample_data)

# Step 4: Save and close
conn.commit()
conn.close()

print("✅ Database and table created with sample data!")
